# Petzold AI Agency — AI College Advantage
Premium responsive landing page built from The AI College Advantage (2026 Edition).

## Run
Open `index.html` in a browser.

## Publish
Upload the folder to any static hosting provider, or connect it to a custom domain.

## Included
- Premium dark SaaS-style design
- Responsive mobile layout
- Interactive prompt-copy buttons
- Advantage / toolkit / income / prompt vault / 30-day plan sections
- Petzold AI Agency branding
